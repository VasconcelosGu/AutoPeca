package View;

import Controller.ClienteController;
import Controller.ProdutoController;
import Model.ClienteModel;
import Model.ProdutoTM;
import Model.ClienteTM;
import Model.ProdutoModel;
import javax.swing.JOptionPane;

public class PrincipalView extends javax.swing.JFrame {
    ClienteTM ClienteModelo;
    ProdutoTM ProdutoModelo;
    ClienteController ClienteC = new ClienteController();
    ProdutoController ProdutoC = new ProdutoController();
    String clienteModo, produtoModo;
    
    public PrincipalView() {
        initComponents();
        setLocationRelativeTo(null);
        setBotoesCliente(false, false, false, true);
        setBotoesProduto(false, false, false, true);
        CarregarTabelaCliente();
        CarregarTabelaProduto();
        BloqueiaCamposCliente();
        BloqueiaCamposProduto();
        clienteModo = "Navegar";
        produtoModo = "Navegar";
    }
    
    public void CarregarTabelaCliente(){
        ClienteModelo = new ClienteTM(ClienteC.ListarClientes());
        tb_clientes.setModel(ClienteModelo);
    }
    
    public void CarregarTabelaProduto(){
        ProdutoModelo = new ProdutoTM(ProdutoC.ListarProdutos());
        tb_produtos.setModel(ProdutoModelo);
    }
    
    public void setBotoesCliente(boolean salvarCliente, boolean editarCliente, boolean excluirCliente, boolean novoCliente) {
        btnC_adicionar.setEnabled(salvarCliente);
        btnC_editar.setEnabled(editarCliente);
        btnC_excluir.setEnabled(excluirCliente);
        btnC_novo.setEnabled(novoCliente);
    }
    
    public void setBotoesProduto(boolean salvarProduto, boolean editarProduto, boolean excluirProduto, boolean novoProduto) {
        btnP_adicionar.setEnabled(salvarProduto);
        btnP_editar.setEnabled(editarProduto);
        btnP_excluir.setEnabled(excluirProduto);
        btnP_novo.setEnabled(novoProduto);
    }
    
    public void LimpaCamposCliente() {
        txtC_nome.setText("");
        txtC_email.setText("");
        txtC_endereco.setText("");
        txtC_cnpj.setText("");
        txtC_cpf.setText("");
        txtC_telefone1.setText("");
        txtC_telefone2.setText("");
        txtC_telefone3.setText("");
    }
    
    public void LimpaCamposProduto() {
        txtP_nome.setText("");
        txtP_codigo.setText("");
        txtP_custo.setText("");
        txtP_preco.setText("");
        txtP_qtd.setText("");
        txtP_qtdMinima.setText("");
    }
    
    public void BloqueiaCamposCliente() {
        txtC_nome.setEnabled(false);
        txtC_email.setEnabled(false);
        txtC_endereco.setEnabled(false);
        txtC_cnpj.setEnabled(false);
        txtC_cpf.setEnabled(false);
        txtC_telefone1.setEnabled(false);
        txtC_telefone2.setEnabled(false);
        txtC_telefone3.setEnabled(false);
    }
    
    public void BloqueiaCamposProduto() {
        txtP_nome.setEnabled(false);
        txtP_codigo.setEnabled(false);
        txtP_custo.setEnabled(false);
        txtP_preco.setEnabled(false);
        txtP_qtd.setEnabled(false);
        txtP_qtdMinima.setEnabled(false);
    }
    
    public void LiberaCamposCliente() {
        txtC_nome.setEnabled(true);
        txtC_email.setEnabled(true);
        txtC_endereco.setEnabled(true);
        txtC_cnpj.setEnabled(true);
        txtC_cpf.setEnabled(true);
        txtC_telefone1.setEnabled(true);
        txtC_telefone2.setEnabled(true);
        txtC_telefone3.setEnabled(true);
    }
    
    public void LiberaCamposProduto() {
        txtP_nome.setEnabled(true);
        txtP_codigo.setEnabled(true);
        txtP_custo.setEnabled(true);
        txtP_preco.setEnabled(true);
        txtP_qtd.setEnabled(true);
        txtP_qtdMinima.setEnabled(true);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane2 = new javax.swing.JTabbedPane();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jTabbedPane4 = new javax.swing.JTabbedPane();
        jComboBox1 = new javax.swing.JComboBox<>();
        jPasswordField1 = new javax.swing.JPasswordField();
        jComboBox2 = new javax.swing.JComboBox<>();
        jToggleButton1 = new javax.swing.JToggleButton();
        principal_pane = new javax.swing.JTabbedPane();
        jInternalFrame1 = new javax.swing.JInternalFrame();
        txtC_telefone1 = new javax.swing.JTextField();
        labelC_endereco = new javax.swing.JLabel();
        txtC_email = new javax.swing.JTextField();
        btnC_adicionar = new javax.swing.JButton();
        txtC_telefone2 = new javax.swing.JTextField();
        labelC_telefone1 = new javax.swing.JLabel();
        txtC_cpf = new javax.swing.JTextField();
        labelC_nome = new javax.swing.JLabel();
        txtC_telefone3 = new javax.swing.JTextField();
        labelC_telefone2 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tb_clientes = new javax.swing.JTable();
        labelC_email = new javax.swing.JLabel();
        labelC_telefone3 = new javax.swing.JLabel();
        btnC_excluir = new javax.swing.JButton();
        labelC_cpf = new javax.swing.JLabel();
        labelC_cnpj = new javax.swing.JLabel();
        txtC_endereco = new javax.swing.JTextField();
        txtC_cnpj = new javax.swing.JTextField();
        txtC_nome = new javax.swing.JTextField();
        btnC_editar = new javax.swing.JButton();
        btnC_novo = new javax.swing.JButton();
        jInternalFrame2 = new javax.swing.JInternalFrame();
        labelP_preco = new javax.swing.JLabel();
        txtP_qtd = new javax.swing.JTextField();
        txtP_codigo = new javax.swing.JTextField();
        txtP_qtdMinima = new javax.swing.JTextField();
        txtP_nome = new javax.swing.JTextField();
        txtP_preco = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tb_produtos = new javax.swing.JTable();
        btnP_excluir = new javax.swing.JButton();
        labelP_custo = new javax.swing.JLabel();
        txtP_custo = new javax.swing.JTextField();
        btnP_editar = new javax.swing.JButton();
        labelP_qtd = new javax.swing.JLabel();
        btnP_adicionar = new javax.swing.JButton();
        labelP_qtdMinima = new javax.swing.JLabel();
        labelP_codigo = new javax.swing.JLabel();
        labelP_nome = new javax.swing.JLabel();
        btnP_novo = new javax.swing.JButton();

        jTabbedPane3.addTab("tab1", jTabbedPane4);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jPasswordField1.setText("jPasswordField1");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jToggleButton1.setText("jToggleButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jInternalFrame1.setVisible(true);

        labelC_endereco.setText("Endereço:");

        txtC_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtC_emailActionPerformed(evt);
            }
        });

        btnC_adicionar.setText("Salvar");
        btnC_adicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnC_adicionarActionPerformed(evt);
            }
        });

        labelC_telefone1.setText("Telefone 1:");

        labelC_nome.setText("Nome:");

        labelC_telefone2.setText("Telefone 2:");

        tb_clientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Email", "Endereco", "CNPJ", "CPF", "Telefone 1", "Telefone 3", "Telefone 3"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tb_clientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_clientesMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tb_clientes);

        labelC_email.setText("Email:");

        labelC_telefone3.setText("Telefone 3:");

        btnC_excluir.setText("Excluir");
        btnC_excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnC_excluirActionPerformed(evt);
            }
        });

        labelC_cpf.setText("CPF:");

        labelC_cnpj.setText("CNPJ:");

        txtC_cnpj.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtC_cnpjActionPerformed(evt);
            }
        });

        btnC_editar.setText("Editar");
        btnC_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnC_editarActionPerformed(evt);
            }
        });

        btnC_novo.setText("Novo");
        btnC_novo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnC_novoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 671, Short.MAX_VALUE)
            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(labelC_cnpj)
                    .addComponent(labelC_cpf)
                    .addComponent(labelC_email)
                    .addComponent(labelC_nome))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtC_email)
                    .addComponent(txtC_cpf)
                    .addComponent(txtC_cnpj, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(txtC_nome))
                .addGap(47, 47, 47)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(labelC_endereco)
                    .addComponent(labelC_telefone1)
                    .addComponent(labelC_telefone2)
                    .addComponent(labelC_telefone3))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtC_endereco)
                    .addComponent(txtC_telefone1)
                    .addComponent(txtC_telefone2)
                    .addComponent(txtC_telefone3, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jInternalFrame1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnC_novo, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnC_adicionar, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnC_editar, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnC_excluir, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jInternalFrame1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelC_nome)
                    .addComponent(txtC_nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelC_endereco)
                    .addComponent(txtC_endereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelC_email)
                    .addComponent(txtC_email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelC_telefone1)
                    .addComponent(txtC_telefone1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelC_cpf)
                    .addComponent(txtC_cpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelC_telefone2)
                    .addComponent(txtC_telefone2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelC_cnpj)
                    .addComponent(txtC_cnpj, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelC_telefone3)
                    .addComponent(txtC_telefone3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnC_excluir)
                    .addComponent(btnC_editar)
                    .addComponent(btnC_adicionar)
                    .addComponent(btnC_novo))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        principal_pane.addTab("Clientes", jInternalFrame1);

        jInternalFrame2.setVisible(true);

        labelP_preco.setText("Preço:");

        txtP_nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtP_nomeActionPerformed(evt);
            }
        });

        tb_produtos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Codigo", "Nome", "Preco", "Custo", "Quantidade", "Qtd Minima"
            }
        ));
        tb_produtos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_produtosMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tb_produtos);

        btnP_excluir.setText("Excluir");
        btnP_excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnP_excluirActionPerformed(evt);
            }
        });

        labelP_custo.setText("Custo");

        txtP_custo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtP_custoActionPerformed(evt);
            }
        });

        btnP_editar.setText("Editar");
        btnP_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnP_editarActionPerformed(evt);
            }
        });

        labelP_qtd.setText("Quantidade:");

        btnP_adicionar.setText("Salvar");
        btnP_adicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnP_adicionarActionPerformed(evt);
            }
        });

        labelP_qtdMinima.setText("Quantidade Mínima");

        labelP_codigo.setText("Código");

        labelP_nome.setText("Nome:");

        btnP_novo.setText("Novo");
        btnP_novo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnP_novoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jInternalFrame2Layout = new javax.swing.GroupLayout(jInternalFrame2.getContentPane());
        jInternalFrame2.getContentPane().setLayout(jInternalFrame2Layout);
        jInternalFrame2Layout.setHorizontalGroup(
            jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 671, Short.MAX_VALUE)
            .addGroup(jInternalFrame2Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(labelP_custo)
                    .addComponent(labelP_preco)
                    .addComponent(labelP_nome)
                    .addComponent(labelP_codigo))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtP_nome)
                    .addComponent(txtP_preco)
                    .addComponent(txtP_custo, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(txtP_codigo))
                .addGap(83, 83, 83)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(labelP_qtd)
                    .addComponent(labelP_qtdMinima))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtP_qtd, javax.swing.GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE)
                    .addComponent(txtP_qtdMinima))
                .addContainerGap(100, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jInternalFrame2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnP_novo, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnP_adicionar, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnP_editar, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnP_excluir, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jInternalFrame2Layout.setVerticalGroup(
            jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jInternalFrame2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelP_codigo)
                    .addComponent(txtP_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelP_qtd)
                    .addComponent(txtP_qtd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelP_nome)
                    .addComponent(txtP_nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelP_qtdMinima)
                    .addComponent(txtP_qtdMinima, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelP_preco)
                    .addComponent(txtP_preco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelP_custo)
                    .addComponent(txtP_custo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnP_novo, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnP_excluir)
                        .addComponent(btnP_editar)
                        .addComponent(btnP_adicionar)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        principal_pane.addTab("Produtos", jInternalFrame2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(principal_pane)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(principal_pane)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtP_nomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtP_nomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtP_nomeActionPerformed

    private void txtP_custoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtP_custoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtP_custoActionPerformed

    private void txtC_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtC_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtC_emailActionPerformed

    private void txtC_cnpjActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtC_cnpjActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtC_cnpjActionPerformed

    private void tb_clientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_clientesMouseClicked
        setBotoesCliente(true, true, true, true);
        BloqueiaCamposCliente();
        int index = tb_clientes.getSelectedRow();
        clienteModo = "Selecao";
        
        if(index >= 0 && index < ClienteModelo.getRowCount()){
            String temp[] = ClienteModelo.getCliente(index);
            txtC_nome.setText(temp[1]);
            txtC_email.setText(temp[2]);
            txtC_endereco.setText(temp[3]);
            txtC_cnpj.setText(temp[4]);
            txtC_cpf.setText(temp[5]);
            txtC_telefone1.setText(temp[6]);
            txtC_telefone2.setText(temp[7]);
            txtC_telefone3.setText(temp[8]);
        }
    }//GEN-LAST:event_tb_clientesMouseClicked

    private void btnC_adicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnC_adicionarActionPerformed
        int id;
        String nome, email, endereco, cnpj, cpf, telefone1, telefone2, telefone3;
        
        nome =  txtC_nome.getText();
        email = txtC_email.getText();
        endereco = txtC_endereco.getText();
        cnpj = txtC_cnpj.getText();
        cpf = txtC_cpf.getText();
        telefone1 = txtC_telefone1.getText();
        telefone2 = txtC_telefone2.getText();
        telefone3 = txtC_telefone3.getText();
        
        if(clienteModo.equals("Novo")) {
            if(ClienteC.SalvarCliente(email, nome, cnpj, cpf, endereco, telefone1, telefone2, telefone3)) {
                JOptionPane.showMessageDialog(null, "Cliente salvo com sucesso.");
            } else {
                JOptionPane.showMessageDialog(null, "Houve um erro ao salvar cliente.");
            }
            
        } else if(clienteModo.equals("Editar")) {
            int index = tb_clientes.getSelectedRow();
            String c[] = ClienteModelo.getCliente(index);
            id = Integer.parseInt(c[0]);
            
            if(ClienteC.AlterarCliente(id, email, nome, cnpj, cpf, endereco, telefone1, telefone2, telefone3)) {
                JOptionPane.showMessageDialog(null, "Cliente alterado com sucesso.");
            } else {
                JOptionPane.showMessageDialog(null, "Houve um erro ao alterar cliente.");
            }
        }
        
        setBotoesCliente(false, false, false, true);
        LimpaCamposCliente();
        BloqueiaCamposCliente();
        CarregarTabelaCliente();
    }//GEN-LAST:event_btnC_adicionarActionPerformed

    private void btnP_novoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnP_novoActionPerformed
        setBotoesProduto(true, false, false, false);
        LimpaCamposProduto();
        LiberaCamposProduto();
        produtoModo = "Novo";
    }//GEN-LAST:event_btnP_novoActionPerformed

    private void btnC_novoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnC_novoActionPerformed
        setBotoesCliente(true, false, false, false);
        LimpaCamposCliente();
        LiberaCamposCliente();
        clienteModo = "Novo";
    }//GEN-LAST:event_btnC_novoActionPerformed

    private void btnC_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnC_editarActionPerformed
        setBotoesCliente(true, false, false, false);
        LiberaCamposCliente();
        clienteModo = "Editar";
    }//GEN-LAST:event_btnC_editarActionPerformed

    private void btnC_excluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnC_excluirActionPerformed
        int index = tb_clientes.getSelectedRow();
        String c[] = ClienteModelo.getCliente(index);
        int id = Integer.parseInt(c[0]);
        if(ClienteC.ExcluirCliente(id)) {
            JOptionPane.showMessageDialog(null, "Cliente excluido com sucesso.");
        } else {
            JOptionPane.showMessageDialog(null, "Houve um erro ao excluir cliente.");
        }
        
        setBotoesCliente(false, false, false, true);
        BloqueiaCamposCliente();
        LimpaCamposCliente();
        CarregarTabelaCliente();
    }//GEN-LAST:event_btnC_excluirActionPerformed

    private void tb_produtosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_produtosMouseClicked
        setBotoesProduto(true, true, true, true);
        BloqueiaCamposProduto();
        int index = tb_produtos.getSelectedRow();
        produtoModo = "Selecao";
        
        if(index >= 0 && index < ProdutoModelo.getRowCount()){
            String temp[] = ProdutoModelo.getProduto(index);
            txtP_codigo.setText(temp[0]);
            txtP_nome.setText(temp[1]);
            txtP_preco.setText(temp[2]);
            txtP_custo.setText(temp[3]);
            txtP_qtd.setText(temp[4]);
            txtP_qtdMinima.setText(temp[5]);
        }
    }//GEN-LAST:event_tb_produtosMouseClicked

    private void btnP_adicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnP_adicionarActionPerformed
        int id, qtd, qtdMin, codigo;
        double preco, custo;
        String nome;
        
         codigo = Integer.parseInt(txtP_codigo.getText());
         nome = txtP_nome.getText();
         preco = Double.parseDouble(txtP_preco.getText());
         custo = Double.parseDouble(txtP_custo.getText());
         qtd = Integer.parseInt(txtP_qtd.getText());
         qtdMin = Integer.parseInt(txtP_qtdMinima.getText());
        
        if(produtoModo.equals("Novo")) {
            if(ProdutoC.SalvarProduto(nome, preco, custo, qtd, qtdMin, codigo)) {
                JOptionPane.showMessageDialog(null, "Produto salvo com sucesso.");
            } else {
                JOptionPane.showMessageDialog(null, "Houve um erro ao salvar produto.");
            }
            
        } else if(produtoModo.equals("Editar")) {
            int index = tb_produtos.getSelectedRow();
            String p[] = ProdutoModelo.getProduto(index);
            id = Integer.parseInt(p[0]);
            
            if(ProdutoC.AlterarProduto(id, nome, preco, custo, qtd, qtdMin, codigo)) {
                JOptionPane.showMessageDialog(null, "Produto alterado com sucesso.");
            } else {
                JOptionPane.showMessageDialog(null, "Houve um erro ao alterar produto.");
            }
        }
        
        setBotoesProduto(false, false, false, true);
        LimpaCamposProduto();
        BloqueiaCamposProduto();
        CarregarTabelaProduto();
    }//GEN-LAST:event_btnP_adicionarActionPerformed

    private void btnP_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnP_editarActionPerformed
        setBotoesProduto(true, false, false, false);
        LiberaCamposProduto();
        produtoModo = "Editar";
    }//GEN-LAST:event_btnP_editarActionPerformed

    private void btnP_excluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnP_excluirActionPerformed
        int index = tb_produtos.getSelectedRow();
        String c[] = ProdutoModelo.getProduto(index);
        int id = Integer.parseInt(c[0]);
        if(ProdutoC.ExcluirProduto(id)) {
            JOptionPane.showMessageDialog(null, "Produto excluido com sucesso.");
        } else {
            JOptionPane.showMessageDialog(null, "Houve um erro ao excluir cliente.");
        }
        
        setBotoesProduto(false, false, false, true);
        BloqueiaCamposProduto();
        LimpaCamposProduto();
        CarregarTabelaProduto();
    }//GEN-LAST:event_btnP_excluirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PrincipalView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PrincipalView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PrincipalView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PrincipalView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PrincipalView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnC_adicionar;
    private javax.swing.JButton btnC_editar;
    private javax.swing.JButton btnC_excluir;
    private javax.swing.JButton btnC_novo;
    private javax.swing.JButton btnP_adicionar;
    private javax.swing.JButton btnP_editar;
    private javax.swing.JButton btnP_excluir;
    private javax.swing.JButton btnP_novo;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JInternalFrame jInternalFrame2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTabbedPane jTabbedPane4;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JLabel labelC_cnpj;
    private javax.swing.JLabel labelC_cpf;
    private javax.swing.JLabel labelC_email;
    private javax.swing.JLabel labelC_endereco;
    private javax.swing.JLabel labelC_nome;
    private javax.swing.JLabel labelC_telefone1;
    private javax.swing.JLabel labelC_telefone2;
    private javax.swing.JLabel labelC_telefone3;
    private javax.swing.JLabel labelP_codigo;
    private javax.swing.JLabel labelP_custo;
    private javax.swing.JLabel labelP_nome;
    private javax.swing.JLabel labelP_preco;
    private javax.swing.JLabel labelP_qtd;
    private javax.swing.JLabel labelP_qtdMinima;
    private javax.swing.JTabbedPane principal_pane;
    private javax.swing.JTable tb_clientes;
    private javax.swing.JTable tb_produtos;
    private javax.swing.JTextField txtC_cnpj;
    private javax.swing.JTextField txtC_cpf;
    private javax.swing.JTextField txtC_email;
    private javax.swing.JTextField txtC_endereco;
    private javax.swing.JTextField txtC_nome;
    private javax.swing.JTextField txtC_telefone1;
    private javax.swing.JTextField txtC_telefone2;
    private javax.swing.JTextField txtC_telefone3;
    private javax.swing.JTextField txtP_codigo;
    private javax.swing.JTextField txtP_custo;
    private javax.swing.JTextField txtP_nome;
    private javax.swing.JTextField txtP_preco;
    private javax.swing.JTextField txtP_qtd;
    private javax.swing.JTextField txtP_qtdMinima;
    // End of variables declaration//GEN-END:variables
}

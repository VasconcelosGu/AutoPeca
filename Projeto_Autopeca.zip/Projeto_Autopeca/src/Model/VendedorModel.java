package Model;

public class VendedorModel {
    private String
            nome,
            endereco,
            telefone,
            nome_usuario,
            senha;
    private int id_vendedor;
    private float comissao;
    
    public VendedorModel() {
        
    }
    
    public VendedorModel(int id, String email, String nome, String nome_usuario, Float comissao, String endereco, String telefone, String senha) {
        this.id_vendedor = id;
        this.nome = nome;
        this.nome_usuario = nome_usuario;
        this.comissao = comissao;
        this.endereco = endereco;
        this.telefone = telefone;
       this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getNome_usuario() {
        return nome_usuario;
    }

    public void setNome_usuario(String nome_usuario) {
        this.nome_usuario = nome_usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public int getId_vendedor() {
        return id_vendedor;
    }

    public void setId_vendedor(int id_vendedor) {
        this.id_vendedor = id_vendedor;
    }

    public float getComissao() {
        return comissao;
    }

    public void setComissao(float comissao) {
        this.comissao = comissao;
    }
}
    